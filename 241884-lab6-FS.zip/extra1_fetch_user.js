// =============================================================================
// Extra 1 - async/await function that returns a valid user object when the API
//           call succeeds and throws an error (rejects) when it does not.
//
// Run:  node extra/extra1_fetch_user.js            (uses a fake API, works offline)
//       node extra/extra1_fetch_user.js --real     (uses the real JSONPlaceholder API,
//                                                   needs internet and Node 18+)
// =============================================================================

// ---- Fake API (so the demo is reproducible without internet) ------------------------
const FAKE_USERS = {
  1: { id: 1, name: 'Ali Khan', email: 'ali@au.edu.pk', username: 'ali' },
  2: { id: 2, name: '', email: 'broken@au.edu.pk', username: 'noName' },   // invalid: empty name
  3: { id: 3, name: 'Sara', email: 'not-an-email', username: 'sara' },     // invalid: bad email
};

function fakeFetch(url) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (url.includes('offline')) {
        reject(new TypeError('fetch failed')); // network failure
        return;
      }
      const id = Number(url.split('/').pop());
      const user = FAKE_USERS[id];
      resolve({
        ok: user !== undefined,
        status: user ? 200 : 404,
        statusText: user ? 'OK' : 'Not Found',
        json: async () => {
          if (url.includes('badjson')) throw new SyntaxError('Unexpected token < in JSON');
          return user ?? {};
        },
      });
    }, 100);
  });
}

// ---- Validation of the user object ----------------------------------------------------
function isValidUser(user) {
  return (
    user !== null &&
    typeof user === 'object' &&
    Number.isInteger(user.id) &&
    typeof user.name === 'string' && user.name.trim() !== '' &&
    typeof user.email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)
  );
}

// ---- THE FUNCTION ---------------------------------------------------------------------
// Returns a Promise that resolves with a valid user object, or rejects with an Error.
async function fetchUser(userId, fetchImplementation = fakeFetch, baseUrl = 'https://api.example.com/users') {
  if (!Number.isInteger(userId) || userId <= 0) {
    throw new TypeError(`userId must be a positive integer, received ${userId}`);
  }

  const url = `${baseUrl}/${userId}`;
  let response;
  try {
    response = await fetchImplementation(url);           // network errors reject here
  } catch (error) {
    throw new Error(`Network error while fetching user ${userId}: ${error.message}`, { cause: error });
  }

  if (!response.ok) {                                    // fetch does NOT reject on 404/500
    throw new Error(`Failed to fetch user ${userId}: HTTP ${response.status} ${response.statusText}`);
  }

  let user;
  try {
    user = await response.json();
  } catch (error) {
    throw new Error(`User ${userId}: response was not valid JSON`, { cause: error });
  }

  if (!isValidUser(user)) {
    throw new Error(`User ${userId}: the API returned an invalid user object`);
  }
  return user;                                           // success: a valid user object
}

// ---- DEMO ------------------------------------------------------------------------------
async function main() {
  const useReal = process.argv.includes('--real');
  const impl = useReal ? fetch : fakeFetch;
  const base = useReal ? 'https://jsonplaceholder.typicode.com/users' : 'https://api.example.com/users';

  const tests = [
    ['valid user', 1, base],
    ['user not found (404)', 99999, base],
    ['invalid user (empty name)', 2, base],
    ['invalid user (bad email)', 3, base],
    ['bad id', -5, base],
    ['network failure', 1, 'https://offline.example.com/users'],
    ['invalid JSON', 1, 'https://badjson.example.com/users'],
  ];

  for (const [label, id, baseUrl] of tests) {
    try {
      const user = await fetchUser(id, impl, baseUrl);
      console.log(`${label.padEnd(28)} -> SUCCESS:`, { id: user.id, name: user.name, email: user.email });
    } catch (error) {
      console.log(`${label.padEnd(28)} -> ERROR: ${error.message}`);
    }
  }
}

main();
