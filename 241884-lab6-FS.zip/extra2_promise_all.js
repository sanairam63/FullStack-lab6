// =============================================================================
// Extra 2 - Promise.all over two async operations; the main promise is
//           ACCEPTED (resolved) only if the details from BOTH are valid,
//           otherwise it is REJECTED.
//
// Operation 1: fetchUser(id)       -> user details
// Operation 2: fetchUserPosts(id)  -> that user's posts
//
// Run:  node extra/extra2_promise_all.js
// =============================================================================

// ---- Fake data + two async operations ---------------------------------------------------
const USERS = {
  1: { id: 1, name: 'Ali Khan', email: 'ali@au.edu.pk' },
  2: { id: 2, name: 'Sara', email: 'sara@au.edu.pk' },
  3: { id: 3, name: '', email: 'bad-email' },        // invalid user details
  4: { id: 4, name: 'Hina', email: 'hina@au.edu.pk' },
};
const POSTS = {
  1: [{ id: 10, userId: 1, title: 'Hello' }, { id: 11, userId: 1, title: 'Second post' }],
  2: [{ id: 20, userId: 99, title: 'Wrong owner' }], // invalid: belongs to another user
  3: [{ id: 30, userId: 3, title: 'Fine post' }],
  // user 4 has no posts entry -> the posts service fails
};

function fetchUser(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = USERS[userId];
      if (user) resolve(user);
      else reject(new Error(`User ${userId} not found`));
    }, 150);
  });
}

function fetchUserPosts(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const posts = POSTS[userId];
      if (posts) resolve(posts);
      else reject(new Error(`Posts for user ${userId} not found`));
    }, 250);
  });
}

// ---- Validators ---------------------------------------------------------------------------
function isValidUser(user) {
  return (
    user !== null && typeof user === 'object' &&
    Number.isInteger(user.id) &&
    typeof user.name === 'string' && user.name.trim() !== '' &&
    typeof user.email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(user.email)
  );
}

function arePostsValid(posts, userId) {
  return (
    Array.isArray(posts) && posts.length > 0 &&
    posts.every((post) => post.userId === userId && typeof post.title === 'string' && post.title.trim() !== '')
  );
}

// ---- THE MAIN PROMISE ----------------------------------------------------------------------
// Promise.all starts BOTH operations at the same time (total time ~ the slower one,
// not the sum) and gives one promise that:
//   * resolves with [user, posts] when BOTH resolve, or
//   * rejects immediately with the first rejection reason.
// After it resolves we validate both results; throwing inside .then() turns the
// main promise into a REJECTED one, returning a value keeps it ACCEPTED.
function loadUserProfile(userId) {
  return Promise.all([fetchUser(userId), fetchUserPosts(userId)]).then(([user, posts]) => {
    if (!isValidUser(user)) {
      throw new Error(`Invalid user details for user ${userId}`);
    }
    if (!arePostsValid(posts, userId)) {
      throw new Error(`Invalid posts for user ${userId}`);
    }
    return { user, posts }; // accepted: both are valid
  });
}

// Same idea written with async/await (equivalent behaviour):
async function loadUserProfileAsync(userId) {
  const [user, posts] = await Promise.all([fetchUser(userId), fetchUserPosts(userId)]);
  if (!isValidUser(user) || !arePostsValid(posts, userId)) {
    throw new Error(`Invalid details for user ${userId}`);
  }
  return { user, posts };
}

// ---- DEMO ------------------------------------------------------------------------------------
const cases = [
  [1, 'both valid -> ACCEPTED'],
  [2, 'user valid, posts invalid -> REJECTED'],
  [3, 'user invalid, posts valid -> REJECTED'],
  [4, 'posts operation fails -> REJECTED'],
  [99, 'both operations fail -> REJECTED (first error)'],
];

async function main() {
  for (const [id, description] of cases) {
    const started = Date.now();
    try {
      const profile = await loadUserProfile(id);
      console.log(`User ${id}: ${description}`);
      console.log(`   ACCEPTED in ${Date.now() - started} ms:`, profile.user.name, `(${profile.posts.length} posts)`);
    } catch (error) {
      console.log(`User ${id}: ${description}`);
      console.log(`   REJECTED in ${Date.now() - started} ms: ${error.message}`);
    }
  }

  console.log('\nAsync/await version for user 1:');
  const profile = await loadUserProfileAsync(1);
  console.log('   ACCEPTED:', profile.user.name);
}

main();
